import 'package:flutter/material.dart';

final primary = Colors.white;
final mint = Color(0xff70b1a1);
const blue = Color(0xff77a0c6);
const choral = Color(0xffb0463c);
const lavender = Color(0xff855f8c);
const pink = Color(0xffcf9496);
